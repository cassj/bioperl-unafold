# ABSTRACT: An empty module to facilitate installation of the Bioperl-compatible Unafold wrappers
package Bio::Tools::Unafold;
BEGIN {
  $Bio::Tools::Unafold::VERSION = '0.001';
}

use Bio::Tools::Run::Unafold::hybrid_ss;
use Bio::Tools::Run::Unafold::hybrid_ss_min;


1;

__END__
=pod

=head1 NAME

Bio::Tools::Unafold - An empty module to facilitate installation of the Bioperl-compatible Unafold wrappers

=head1 VERSION

version 0.001

=head1 AUTHOR

Cass Johnston <cassjohnston@gmail.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2010 by Cass Johnston.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

=cut

